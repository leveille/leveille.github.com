def py_update_name(username, first_name, last_name):
    from django.contrib.auth.models import User
    user = User.objects.get(username=username)
    user.first_name = first_name
    user.last_name = last_name
    user.save()

def py_get_full_name(username='leveille'):
    from django.contrib.auth.models import User
    user = User.objects.get(username=username)
    return user.get_full_name()
