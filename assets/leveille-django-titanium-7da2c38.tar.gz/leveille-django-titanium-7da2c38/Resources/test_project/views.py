def index():
    kwargs = {'foo': 'bar'}
    return _render_template('index', **kwargs)

def about():
    return _render_template('about')

def _render_template(template_name, **kwargs):
    from django.template import loader, Context
    t = loader.get_template('%s.html' % template_name)
    c = Context(kwargs)
    return t.render(c)
