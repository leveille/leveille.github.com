def py_get_db():
    from test_project import settings
    return settings.DATABASES['default']['NAME']
