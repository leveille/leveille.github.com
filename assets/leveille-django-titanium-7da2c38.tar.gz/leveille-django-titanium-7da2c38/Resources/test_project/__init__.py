import sys, os
os.environ['DJANGO_SETTINGS_MODULE'] = 'test_project.settings'
